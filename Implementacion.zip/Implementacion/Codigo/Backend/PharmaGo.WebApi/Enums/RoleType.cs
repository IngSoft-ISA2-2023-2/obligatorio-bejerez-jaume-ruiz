﻿namespace PharmaGo.WebApi.Enums
{
    public enum RoleType
    {
        Administrator = 1,
        Employee = 2,
        Owner = 3
    }
}
