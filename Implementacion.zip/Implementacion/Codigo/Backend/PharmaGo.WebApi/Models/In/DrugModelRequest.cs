﻿using System;
namespace PharmaGo.WebApi.Models.In
{
	public class DrugModelRequest
	{
        public string Code { get; set; }
    }
}

