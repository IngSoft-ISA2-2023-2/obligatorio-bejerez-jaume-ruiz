﻿namespace PharmaGo.WebApi.Models.In
{
    public class LoginModelRequest
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
