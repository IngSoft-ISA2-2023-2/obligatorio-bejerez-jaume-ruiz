﻿using PharmaGo.Domain.Enums;

namespace PharmaGo.Domain.Entities
{
    public class UnitMeasure
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public bool Deleted { get; set; }
    }
}