export interface Presentation {
    id: number;
    name: string;
  }
  