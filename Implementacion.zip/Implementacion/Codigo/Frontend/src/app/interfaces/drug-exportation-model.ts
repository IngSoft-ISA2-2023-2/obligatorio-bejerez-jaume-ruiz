import { Parameter } from './parameter';

export interface DrugExportationModel {
  formatName: string;
  parameters: Parameter[];
}
