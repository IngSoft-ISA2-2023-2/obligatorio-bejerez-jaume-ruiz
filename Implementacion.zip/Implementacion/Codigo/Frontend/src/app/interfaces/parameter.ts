export interface Parameter {
  inputName: string;
  inputValue: string;
}
