export interface UnitMeasure {
    id: number;
    name: string;
  }
  