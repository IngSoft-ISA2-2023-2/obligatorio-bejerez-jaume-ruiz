import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-footer',
  templateUrl: './custom-footer.component.html',
  styleUrls: ['./custom-footer.component.css']
})
export class CustomFooterComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
  }
}
